package cn.edu.test.controller;

import cn.edu.test.api.TestService;
import cn.edu.test.mapper.TestUserMapper;
import cn.edu.test.model.Person;
import cn.edu.test.model.TestUser;
import cn.edu.test.model.rpc.LoginRequest;
import cn.edu.test.model.rpc.LoginResponse;
import cn.edu.test.model.rpc.RpcPerson;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("test/")
// 本地主机 127.0.0.1 or localhost
// http://10.222.122.111 -> 路由器 -> 运营商服务器 -> host缓存文件 -> 对应的机器
// http://198.0.0.2/test -> 路由器 -> 路由器下面的机器 -> 手机ip 198.0.0.2 -> 请求转发手机
// ip 公网ip 内网ip  10.222.122.111  198.127.0.1

// 注入
public class TestController {
    private HashMap<String, Person> loginMap = new HashMap<>();
    private TestUserMapper testUserMapper;
    @Autowired
    public void setTestUserMapper(TestUserMapper userMapper) {
        this.testUserMapper = userMapper;
    }
    @Reference
    TestService testService;

    @RequestMapping(value = "login/", method = RequestMethod.POST)
    public @ResponseBody Object Login(@RequestBody Person person) {
        System.out.println("person的名字是:" + person.getName());
        LoginRequest request = new LoginRequest();
        request.account = person.getAccount();
        request.name = person.getName();
        request.password = person.getPassword();
        LoginResponse response = testService.Login(request);
        loginMap.put(response.token, person);
        return response.token;
    }

    @RequestMapping(value = "register/", method = RequestMethod.POST)
    public @ResponseBody Object Register(@RequestBody Person person) {
        // account 不能相同
        QueryWrapper<TestUser> userQuery = new QueryWrapper<>();
        userQuery.eq("account", person.getAccount());
        TestUser user = testUserMapper.selectOne(userQuery);
        if (user != null) {
            return "用户名重复";
        }
        TestUser testUser = new TestUser();
        testUser.name = person.getName();
        testUser.account = person.getAccount();
        testUser.password = person.getPassword();
        testUserMapper.insert(testUser);
        return "注册成功";
    }

    // key - value
    @RequestMapping(value = "search_person/", method = RequestMethod.GET)
    public @ResponseBody Object SearchPerson(@RequestParam String name, @RequestParam String token) {
        if (!hasLogin(token)) {
            return "用户未登陆";
        }
        RpcPerson rpcPerson = new RpcPerson();
        rpcPerson.name = name;
        List<RpcPerson> resultList = testService.SearchPerson(rpcPerson);
        String result = "";
        for (RpcPerson user : resultList) {
            result += ("用户: " + user.name + "账号:" + user.account + "\n");
        }
        System.out.println("符合"+name+"的是\n"+result);
        return "符合"+name+"的是\n"+result;
    }

    public boolean hasLogin(String token) {
        if (!loginMap.containsKey(token) || token == null) {
            return false;
        }
        return true;
    }
//    @RequestMapping(value = "login_v2/", method = RequestMethod.GET)
//    public @ResponseBody Object LoginV2(@RequestParam String name, @RequestParam String account, @RequestParam String password) {
//        Person person = new Person(account, password, name);
//        System.out.println("person的名字是:" + person.getName());
//        if (person.same(Person.defaultAccount, Person.defaultPassword)) {
//            return "登陆成功";
//        }
//        return "登陆失败";
//    }
}
