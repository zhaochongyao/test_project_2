package cn.edu.test.model;

import lombok.Data;

@Data
public class TestUser {
    public long id;
    public String name;
    public String account;
    public String password;
}
