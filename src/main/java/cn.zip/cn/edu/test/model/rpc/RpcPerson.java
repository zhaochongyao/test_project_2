package cn.edu.test.model.rpc;

import java.io.Serializable;

public class RpcPerson implements Serializable {
    public String account;      //账号
    public  String password;    // 密码
    public  String name;        // 姓名
}
